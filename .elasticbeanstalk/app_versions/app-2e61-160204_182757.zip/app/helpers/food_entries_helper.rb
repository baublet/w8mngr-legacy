module FoodEntriesHelper
end
