require 'test_helper'

class FoodEntriesControllerTest < ActionController::TestCase

end
