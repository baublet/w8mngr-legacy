class WelcomeController < ApplicationController
  def index
  end

  def privacy_policy
  end

  def terms_of_service
  end

  def getting_started
  end

  def contact_form
  end
end
